# flutter_sqflite

A new Flutter project.

watch tutorial on Youtube:https://youtube.com/playlist?list=PLoqGlc-GpLmzsDIrtmM71fq_da1bltHl3



https://user-images.githubusercontent.com/78899995/168964931-1050949f-aca3-4188-950f-d36d7a710cef.mp4


This repository is for(crud) create, read, update and delete in sqflite in flutter.
-
add this packages:
uuid-
provider-
sqflite-
path_provider.

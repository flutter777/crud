package com.example.flutter_sqflite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
